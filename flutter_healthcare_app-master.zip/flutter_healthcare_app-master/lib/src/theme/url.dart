class url{
  static String BASE_URL = 'http://172.16.61.221:8059/admins.asmx/';
}