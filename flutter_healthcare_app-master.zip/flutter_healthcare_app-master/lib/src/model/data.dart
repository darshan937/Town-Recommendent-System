final doctorMapList = [
  {
    "name": "Dr. David Kemp",
    "type": "Heart Sergeon",
    "rating": 4.5,
    "goodReviews": 79.2,
    "totalScore": 93.2,
    "satisfaction": 85.2,
    "isfavourite": true,
    "image": "assets/doctor.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. katthy Mathews",
    "type": "Neurology",
    "rating": 3.5,
    "goodReviews": 93.2,
    "totalScore": 72.2,
    "satisfaction": 89.2,
    "isfavourite": false,
    "image": "assets/doctor_4.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "DR. Morris",
    "type": "Cardio Sergeon",
    "rating": 2.5,
    "goodReviews": 88.2,
    "totalScore": 93.94,
    "satisfaction": 78.2,
    "isfavourite": false,
    "image": "assets/doctor_3.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
  {
    "name": "Dr. Bruce Banner",
    "type": "Heart Sergeon",
    "rating": 1.5,
    "goodReviews": 12.2,
    "totalScore": 75.2,
    "satisfaction": 84.2,
    "isfavourite": true,
    "image": "assets/doctor_1.png",
    "education": "MBBS",
    "description":
        "A doctor can be found in several settings, including public health organization, group practices and  hospitals They have some of the most diverse and challenging careears available and part of a universally well-respected profession",
    "location": "Dhaka",
    "constFee": "1000"
  },
];

final appointmentList = [
  {
    "name": "Jone",
    "date": "16",
    "time": "6.30 pm",
    "age": "22",
    "gender": "Male",
    "appointmentId": "2340187",
    "reason":
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco"
  },
  {
    "name": "Kabir",
    "date": "16",
    "time": "6.30 pm",
    "age": "22",
    "gender": "Male",
    "appointmentId": "2340187",
    "reason":
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco"
  },
  {
    "name": "Ali",
    "date": "16",
    "time": "6.30 pm",
    "age": "37",
    "gender": "Male",
    "appointmentId": "2340187",
    "reason":
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco"
  },
  {
    "name": "Maria",
    "date": "16",
    "time": "6.30 pm",
    "age": "22",
    "gender": "Female",
    "appointmentId": "2340187",
    "reason":
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco"
  },
  {
    "name": "Jone",
    "date": "16",
    "time": "6.30 pm",
    "age": "27",
    "gender": "Male",
    "appointmentId": "2340187",
    "reason":
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco"
  }
];

final medicineList = [
  {
    "id": "1",
    "medicineName": "Medicine Name",
    "companyName": "Comapny Name",
    "price": "6.0",
    "genericName": "Manufacture Name",
    "image": "",
  },
  {
    "id": "2",
    "medicineName": "Medicine Name",
    "companyName": "Comapny Name",
    "price": "1.86",
    "genericName": "Manufacture Name",
    "image": "",
  },
  {
    "id": "3",
    "medicineName": "Medicine Name",
    "companyName": "Comapny Name",
    "price": "1.55",
    "genericName": "Manufacture Name",
    "image": "",
  },
  {
    "id": "4",
    "medicineName": "Medicine Name",
    "companyName": "Comapny Name",
    "price": "1.97",
    "genericName": "Manufacture Name",
    "image": "",
  },
];
