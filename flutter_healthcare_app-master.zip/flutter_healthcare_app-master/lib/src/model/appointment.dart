class Appointment{
 String patientuid;
 String doctorid;
 String dates;
 String timeid;
 String reasons;
 String paymen;

 Appointment(this.patientuid, this.doctorid, this.dates, this.timeid,
     this.reasons, this.paymen);


}