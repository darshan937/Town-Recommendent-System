class Registration{
  String username;
  String firstname;
  String lastname;
  String useremail;
  String userphone;
  String userpass;
  String address;
  String gender;
  String dob;

  Registration(this.username, this.firstname, this.lastname, this.useremail,
      this.userphone, this.userpass, this.address, this.gender, this.dob);


}